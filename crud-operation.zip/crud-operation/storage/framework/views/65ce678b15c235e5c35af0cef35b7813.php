<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.bunny.net">
</head>
<body>
<section class="vh-100 gradient-custom">
    <div class="container py-5 h-100">
                    <div class="card-body p-4 p-md-5">
                        <a href = "<?php echo e(URL('index')); ?>"  type="button" class="btn btn-secondary float-end ml-auto btn-lg"><i class="far fa-thumbs-up">Add New</i></a>
                        <h3 class="mb-4 pb-2 pb-md-0 mb-md-5">Registration Table</h3>
                             <table class="table">
                                <thead>
                                <tr>
                                    <th scope="col">S.No</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Date Of birth</th>
                                    <th scope="col">Email Id</th>
                                    <th scope="col">Mobile No</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>










                                <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                </tr>
                                </tbody>
                            </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

</body>
</html>
<?php /**PATH D:\laravel-projects\crud-operation\resources\views/get_data.blade.php ENDPATH**/ ?>