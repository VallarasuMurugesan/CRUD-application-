<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.bunny.net">
</head>
<body>
<section class="vh-100 gradient-custom">
    <div class="container py-5 h-100">
                    <div class="card-body p-4 p-md-5">
                        <a href = "<?php echo e(URL('index')); ?>"  type="button" class="btn btn-secondary float-end ml-auto btn-lg">Add New</a>
                        <h3 class="mb-4 pb-2 pb-md-0 mb-md-5">Registration Table</h3>
                             <table class="table">
                                <thead>
                                <tr>
                                    <th scope="col">S.No</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Date Of birth</th>
                                    <th scope="col">Email Id</th>
                                    <th scope="col">Mobile No</th>
                                    <th scope="col">Gender</th>
                                    <th scope="col">Status</th>
                                </tr>
                                </thead>
                                <tbody>
                                 <?php $__currentLoopData = $register_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $register): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <?php
                                    if($register->gender == 0){
                                        $gender = 'Male';
                                    }
                                    elseif($register->gender == 1){
                                        $gender = 'Female';
                                    }
                                    else {
                                        $gender = 'Other';
                                    }
                                    ?>
                                     <tr>
                                        <td><?php echo e($key); ?></td>
                                        <td><?php echo e($register->name); ?></td>
                                        <td><?php echo e($register->dob); ?></td>
                                        <td><?php echo e($register->email_id); ?></td>
                                        <td><?php echo e($register->mobile_no); ?></td>
                                        <td><?php echo e($gender); ?></td>
                                        <td><a href ="<?php echo e(URL('edit/'.$register->id)); ?>" class="btn btn-primary btn-xs"> Edit</a>
                                            <a href ="<?php echo e(URL('delete/'.$register->id)); ?>" class="btn btn-danger btn-xs">Delete</a></td>
                                    </tr>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

</body>
</html>
<?php /**PATH D:\laravel-projects\crud-operation\resources\views/fetch_all.blade.php ENDPATH**/ ?>