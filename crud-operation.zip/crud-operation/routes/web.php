<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DemoController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/',[DemoController::class,'fetchAll']);
Route::get('/index',[DemoController::class,'index']);
Route::post('/insert',[DemoController::class,'insert_data'])->name('insert_data');
Route::get('/fetchAll',[DemoController::class,'fetchAll']);
Route::get('/edit/{id}',[DemoController::class,'edit']);
Route::post('update/{id}', [DemoController::class, 'update']);
Route::get('delete/{id}', [DemoController::class, 'delete']);
