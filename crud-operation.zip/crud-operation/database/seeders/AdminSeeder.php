<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
class AdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('registers')->insert([
            'name' => 'hi',
            'email_id' => 'jhsdj@mail.com',
            'mobile_no' => '3535352',
            'dob' => '02-12-2000',
        ]);

    }
}

