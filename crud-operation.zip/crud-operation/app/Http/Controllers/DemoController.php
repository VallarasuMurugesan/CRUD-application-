<?php

namespace App\Http\Controllers;
//use App\Http\Requests;
use Illuminate\Http\Request;
use App\Models\Register;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;

class DemoController extends Controller
{
    public function __construct() {

    }

    public function index()
    {
        return view('index');
    }


    public function insert_data(Request $request)
    {
//        dd($request->all());
       $request->validate([
            'name' => 'required',
            'dob' => 'required',
            'email_id' => 'required',
            'mobile_no' => 'required',
        ]);
        $registered = new Register();
        $registered->name = $request->input('name');
        $registered->dob = $request->input('dob');
        $registered->email_id = $request->input('email_id');
        $registered->mobile_no = $request->input('mobile_no');
        $registered->gender = $request->input('gender');
        $registered->qualification = $request->input('qualification');
        $registered->lname = $request->input('lname');
        $registered->save();
        return redirect('fetchAll')->with('success','Registered Successfully');
    }

    public function fetchAll()
    {
        $listAll = Register::all();
        return view('fetch_all')->with('register_list',$listAll);
    }



    public function edit($id): \Illuminate\Contracts\View\View|\Illuminate\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\Foundation\Application
    {
        $registered = Register::find($id);
        return view('edit', compact('registered'));
    }

    public function update(Request $request, $id): \Illuminate\Http\RedirectResponse
    {
        $registered = Register::find($id);
        $registered->name = $request->input('name');
        $registered->dob = $request->input('dob');
        $registered->email_id = $request->input('email_id');
        $registered->mobile_no = $request->input('mobile_no');
        $registered->gender = $request->input('gender');
        $registered->qualification = $request->input('qualification');
        $registered->lname = $request->input('lname');
        $registered->save();
        return redirect('fetchAll')->with('status','Updated Successfully');
    }

    public function delete($id)
    {
        Register::where('id', $id)->delete();
        return Redirect::to('/')->with('status','Deleted Successfully');
    }

}
